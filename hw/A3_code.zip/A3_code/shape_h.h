#ifndef __ALL_SHAPES_H__
#define __ALL_SHAPES_H__

#include "Shape.h"
#include "shapes.h"

#endif
