# CS432
Drexel University CS432 Interactive Computer Graphics

Squares are placed with left click, triangles with right click, spacebar toggles animation. I transformed my shapes using translation and 
rotatin matrices, using the mat3 class. I started the assignment very late, so the structure of user input is not how I'd like it. There will
be an interface that describes how user input can be described, and there will be child classes for different types of input.

used g++ to compile on a linux system (Ubuntu). 
