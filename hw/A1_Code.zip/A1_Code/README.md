# CS432
Drexel University CS432 Interactive Computer Graphics

I created extended the classes that were provided (Drawable and Shape). I made a significant amount of changes to the structure and content of those classes, and utilized them to make some other classes (Cricle and Triangle). I think the class hierachy is architected well, and should be easily extended to more complex shapes. The on;y "hacky" solution was making the square, which consists of two triangles. 

used g++ to compile on a linux system (Ubuntu). 
