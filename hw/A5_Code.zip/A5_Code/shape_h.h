#ifndef __ALL_SHAPES_H__
#define __ALL_SHAPES_H__

#include "Shape.h"
//#include "Point.h"
//#include "Line.h"
#include "Triangle.h"
//#include "Circle.h"
//#include "Rectangle.h"
//#include "Polyhedron.h"
#include "Sphere.h"

#endif
